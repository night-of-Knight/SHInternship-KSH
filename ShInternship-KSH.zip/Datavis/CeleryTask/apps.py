from django.apps import AppConfig


class CelerytaskConfig(AppConfig):
    name = 'CeleryTask'
